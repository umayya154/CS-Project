# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'HomeWindow.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets

#from OtherWindow import Ui_otherWindow
class Ui_HomeWindow(object):
    def setupUi(self, HomeWindow):
        HomeWindow.setObjectName("HomeWindow")
        HomeWindow.resize(766, 600)
        HomeWindow.setStyleSheet("background-color: rgb(170, 0, 0);")
        self.centralwidget = QtWidgets.QWidget(HomeWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(180, 30, 391, 41))
        font = QtGui.QFont()
        font.setFamily("Segoe UI Symbol")
        font.setPointSize(15)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet("color: rgb(255, 255, 255);\n"
"background-color: rgb(170, 0, 0);")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(110, 200, 611, 161))
        font = QtGui.QFont()
        font.setPointSize(13)
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(110, 360, 100, 30))
        self.pushButton.clicked.connect(lambda:self.closescr(HomeWindow))
        #self.pushButton.clicked.connect(self.openWindow)
        font = QtGui.QFont()
        font.setPointSize(13)
        self.label_2.setFont(font)
        self.label_2.setStyleSheet("color: rgb(255, 255, 255);")
        self.label_2.setObjectName("label_2")
        HomeWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(HomeWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 790, 21))
        self.menubar.setObjectName("menubar")
        HomeWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(HomeWindow)
        self.statusbar.setObjectName("statusbar")
        HomeWindow.setStatusBar(self.statusbar)

        self.retranslateUi(HomeWindow)
        QtCore.QMetaObject.connectSlotsByName(HomeWindow)
    def closescr(self, HomeWindow):
        HomeWindow.hide()

    def retranslateUi(self, HomeWindow):
        _translate = QtCore.QCoreApplication.translate
        HomeWindow.setWindowTitle(_translate("HomeWindow", "MainWindow"))
        self.label.setText(_translate("HomeWindow", "Analysis of Spine Abnormalities"))
        self.label_2.setText(_translate("HomeWindow", "Overview of Project:\n"
"The project of spine abnormalities based automatic system is proposed to identify\n"
"and diagnose the diseases and recommend suitable treatment for diseases like\n"
"scoliosis, vertebral fracture and spondylolisthesis to alleviate the eﬀects of \n"
"these diagnosed diseases. The purpose of this automation is to  reduce human\n"
" loss by replacing the traditional and manual methods used in the medical sector.   "))
        self.pushButton.setText(_translate("otherWindow", "Back"))

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    HomeWindow = QtWidgets.QMainWindow()
    ui = Ui_HomeWindow()
    ui.setupUi(HomeWindow)
    HomeWindow.show()
    sys.exit(app.exec_())
