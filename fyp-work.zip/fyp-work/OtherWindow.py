# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'OtherWindow.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
from HomeWindow import Ui_HomeWindow

from segwindow import Ui_segWindow
class Ui_otherWindow(object):
    def openWindow(self):
        self.window = QtWidgets.QMainWindow()
        self.ui = Ui_HomeWindow()
        self.ui.setupUi(self.window)
        self.window.show()
    def openanotherwindow(self):
        self.windo = QtWidgets.QMainWindow()
        self.ui = Ui_segWindow()
        self.ui.setupUi(self.windo)
        self.windo.show()
    def setupUi(self, otherWindow):
        otherWindow.setObjectName("otherWindow")
        otherWindow.resize(747, 541)
        font = QtGui.QFont()
        font.setFamily("Segoe UI Symbol")
        font.setBold(True)
        font.setWeight(75)
        otherWindow.setFont(font)
        otherWindow.setStyleSheet("background-color: rgb(170, 0, 0);")
        self.centralwidget = QtWidgets.QWidget(otherWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(190, 10, 391, 41))
        font = QtGui.QFont()
        font.setFamily("Segoe UI Symbol")
        font.setPointSize(15)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet("color: rgb(255, 255, 255);")
        self.label.setObjectName("label")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(280, 90, 121, 51))
        self.pushButton.clicked.connect(self.openWindow)
        font = QtGui.QFont()
        font.setPointSize(10)
        self.pushButton.setFont(font)
        self.pushButton.setStyleSheet("color: rgb(255, 255, 255);")
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(280, 170, 121, 51))
        self.pushButton_2.clicked.connect(self.openanotherwindow)
        font = QtGui.QFont()
        font.setPointSize(10)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setStyleSheet("color: rgb(255, 255, 255);")
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(280, 250, 121, 51))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setStyleSheet("color: rgb(255, 255, 255);")
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_4 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_4.setGeometry(QtCore.QRect(280, 330, 121, 51))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.pushButton_4.setFont(font)
        self.pushButton_4.setStyleSheet("color: rgb(255, 255, 255);")
        self.pushButton_4.setObjectName("pushButton_4")
        otherWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(otherWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 747, 21))
        self.menubar.setObjectName("menubar")
        otherWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(otherWindow)
        self.statusbar.setObjectName("statusbar")
        otherWindow.setStatusBar(self.statusbar)

        self.retranslateUi(otherWindow)
        QtCore.QMetaObject.connectSlotsByName(otherWindow)

    def retranslateUi(self, otherWindow):
        _translate = QtCore.QCoreApplication.translate
        otherWindow.setWindowTitle(_translate("otherWindow", "MainWindow"))
        self.label.setText(_translate("otherWindow", "Analysis of Spine Abnormalities"))
        self.pushButton.setText(_translate("otherWindow", "Home"))
        self.pushButton_2.setText(_translate("otherWindow", "Segmentation"))
        self.pushButton_3.setText(_translate("otherWindow", "Classification"))
        self.pushButton_4.setText(_translate("otherWindow", "Report"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    otherWindow = QtWidgets.QMainWindow()
    ui = Ui_otherWindow()
    ui.setupUi(otherWindow)
    otherWindow.show()
    sys.exit(app.exec_())
