# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'segmentation.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_otherwindow(object):
    def setupUi(self, otherwindow):
        otherwindow.setObjectName("otherwindow")
        otherwindow.resize(622, 497)
        otherwindow.setStyleSheet("background-color: rgb(170, 0, 0);")
        self.label = QtWidgets.QLabel(otherwindow)
        self.label.setGeometry(QtCore.QRect(70, 10, 351, 31))
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label.setFont(font)
        self.label.setStyleSheet("color: rgb(255, 255, 255);")
        self.label.setObjectName("label")
        self.pushButton_5 = QtWidgets.QPushButton(otherwindow)
        self.pushButton_5.setGeometry(QtCore.QRect(140, 400, 91, 23))
        self.pushButton_5.setStyleSheet("background-color: rgb(170, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.pushButton_5.setObjectName("pushButton_5")
        self.pushButton_6 = QtWidgets.QPushButton(otherwindow)
        self.pushButton_6.setGeometry(QtCore.QRect(370, 400, 81, 23))
        self.pushButton_6.setStyleSheet("background-color: rgb(170, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.pushButton_6.setObjectName("pushButton_6")
        self.label_2 = QtWidgets.QLabel(otherwindow)
        self.label_2.setGeometry(QtCore.QRect(90, 130, 221, 211))
        self.label_2.setText("")
        self.label_2.setPixmap(QtGui.QPixmap("../../../../../../../../../../Downloads/datasetS.S/datasetS.S/c2mask2c.png"))
        self.label_2.setObjectName("label_2")

        self.retranslateUi(otherwindow)
        QtCore.QMetaObject.connectSlotsByName(otherwindow)

    def retranslateUi(self, otherwindow):
        _translate = QtCore.QCoreApplication.translate
        otherwindow.setWindowTitle(_translate("otherwindow", "Dialog"))
        self.label.setText(_translate("otherwindow", "Identification of Spine Abnormalities"))
        self.pushButton_5.setText(_translate("otherwindow", "Output "))
        self.pushButton_6.setText(_translate("otherwindow", "Back"))
