# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SegmentedWindow.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


