# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'segwindow.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_segWindow(object):
    def setupUi(self, segWindow):
        segWindow.setObjectName("segWindow")
        segWindow.resize(800, 600)
        segWindow.setStyleSheet("background-color: rgb(170, 0, 0);")
        self.centralwidget = QtWidgets.QWidget(segWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(100, 0, 351, 31))
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label.setFont(font)
        self.label.setStyleSheet("color: rgb(255, 255, 255);")
        self.label.setObjectName("label")
        self.pushButton_5 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_5.setGeometry(QtCore.QRect(500, 420, 91, 23))
        self.pushButton_5.setStyleSheet("background-color: rgb(170, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.pushButton_5.setObjectName("pushButton_5")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(420, 120, 251, 221))
        self.label_2.setText("")
        self.label_2.setPixmap(QtGui.QPixmap("../../../../../../../../../../../Downloads/datasetS.S/datasetS.S/c2mask2c.png"))
        self.label_2.setObjectName("label_2")
        self.pushButton_6 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_6.setGeometry(QtCore.QRect(150, 420, 81, 23))
        self.pushButton_6.setStyleSheet("background-color: rgb(170, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.pushButton_6.setObjectName("pushButton_6")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(60, 120, 271, 221))
        self.label_3.setText("")
        self.label_3.setPixmap(QtGui.QPixmap("../../../../../../../../../../../Downloads/datasetS.S/datasetS.S/c02.png"))
        self.label_3.setObjectName("label_3")
        self.pushButton_7 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_7.setGeometry(QtCore.QRect(150, 490, 81, 23))
        self.pushButton_7.clicked.connect(lambda:self.closescr(segwindow))
        self.pushButton_7.setStyleSheet("background-color: rgb(170, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.pushButton_7.setObjectName("pushButton_7")
        segWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(segWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 21))
        self.menubar.setObjectName("menubar")
        segWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(segWindow)
        self.statusbar.setObjectName("statusbar")
        segWindow.setStatusBar(self.statusbar)

        self.retranslateUi(segWindow)
        QtCore.QMetaObject.connectSlotsByName(segWindow)
    def closescr(self, HomeWindow):
        HomeWindow.hide()

    def retranslateUi(self, segWindow):
        _translate = QtCore.QCoreApplication.translate
        segWindow.setWindowTitle(_translate("segWindow", "MainWindow"))
        self.label.setText(_translate("segWindow", "Identification of Spine Abnormalities"))
        self.pushButton_5.setText(_translate("segWindow", "Output "))
        self.pushButton_6.setText(_translate("segWindow", "Input"))
        self.pushButton_7.setText(_translate("segWindow", "Back"))
